from __future__ import annotations

import json
import sys
import zipfile
from datetime import datetime
from html import escape
from io import BytesIO
from pathlib import Path
from typing import Any
import xml.etree.ElementTree as ET

import streamlit as st
import streamlit.components.v1 as components
import yaml

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from validators.optimize_prompt import build_optimized_prompt, recommend_prompt_improvements
from validators.validate_quality import score_business_quality
from validators.validate_structure import validate_output


ALLOWED_OUTPUT_DESTINATIONS = [
    "Chat",
    "Workflow",
    "Agreement Management",
    "Salesforce",
]

ALLOWED_OUTPUT_FORMATS = [
    "JSON",
    "Markdown Table",
    "HTML Table",
    "Plain Language Summary",
    "Workflow Variables",
]

TEMPLATE_PATH = ROOT / "prompts" / "prompt_templates.yaml"
PROMPT_LIBRARY_PATH = ROOT / "data" / "agent_worksheet_prompts.xlsx"
RULES_DIR = ROOT / "rules"
GEMINI_CHAT_URL = "https://gemini.google.com/app"

GENERATION_MODES = [
    "Use Prompt Library",
    "Customize existing prompt",
    "Generate with Gemini Agent",
]

DEFAULT_LIBRARY_TITLE_HINT = "Renewals + Risk"


def main() -> None:
    st.set_page_config(page_title="Docusign IAM Prompt Builder", layout="wide")
    _inject_styles()

    templates = _load_yaml(TEMPLATE_PATH)["templates"]
    template_id = _first_active_template_id(templates)
    selected_template = templates[template_id]
    rules = _load_rules(template_id, selected_template)
    prompt_library = _load_default_prompt_library()

    _render_app_header()

    context = _context_form(selected_template, rules, prompt_library)
    _render_section_break()

    if selected_template["status"] != "active":
        st.info("Select a supported prompt-library pattern to generate and validate a complete MVP prompt.")
        return

    missing_fields = _missing_prompt_fields(context)
    generated_prompt = "" if missing_fields else _build_generated_artifact(context, selected_template, rules)

    with st.sidebar:
        _render_sidebar_brand()
        _render_prompt_history_sidebar(context, generated_prompt, missing_fields)

    prompt_tab, agreement_pack_tab, qa_tab = st.tabs(["Prompt Builder", "Agreement Pack Builder", "QA Wizard"])

    with prompt_tab:
        _render_prompt_builder(context, template_id, generated_prompt, missing_fields, rules)

    with agreement_pack_tab:
        _render_agreement_pack_builder(context, template_id, missing_fields, rules)

    with qa_tab:
        _qa_wizard(template_id, context, generated_prompt, rules)


def _render_prompt_builder(
    context: dict[str, Any],
    template_id: str,
    generated_prompt: str,
    missing_fields: list[str],
    rules: dict[str, Any],
) -> None:
    if context["generation_mode"] == "Generate with Gemini Agent":
        st.subheader("Gemini Agent Brief")
        _render_gemini_mode_steps()
        if missing_fields:
            st.info(f"Complete {', '.join(missing_fields)} to generate the Gemini Agent Brief.")
        st.text_area("Copy-ready Gemini Agent Brief", value=generated_prompt, height=520, label_visibility="collapsed")
        _render_gemini_actions(generated_prompt, disabled=bool(missing_fields))
        st.download_button(
            "Download Gemini Agent Brief",
            generated_prompt,
            file_name=f"{template_id}_gemini_agent_brief.txt",
            disabled=bool(missing_fields),
        )
    else:
        generated_label = "Generated Worksheet Prompt" if context.get("library_prompt_type") == "Worksheet" else "Generated AI Agent Prompt"
        st.subheader(generated_label)
        if missing_fields:
            st.info(f"Complete {', '.join(missing_fields)} to generate the prompt.")
        st.text_area("Copy-ready prompt", value=generated_prompt, height=560, label_visibility="collapsed")
        st.download_button("Download prompt", generated_prompt, file_name=f"{template_id}_prompt.txt", disabled=bool(missing_fields))

    with st.expander("Output rules", expanded=False):
        _render_output_rules(rules, context)


def _render_agreement_pack_builder(
    context: dict[str, Any],
    template_id: str,
    missing_fields: list[str],
    rules: dict[str, Any],
) -> None:
    agreement_pack_brief = "" if missing_fields else _build_demo_agreement_pack_brief(context, rules)

    st.subheader("Demo Agreement Pack Brief")
    _render_agreement_pack_steps()
    if missing_fields:
        st.info(f"Complete {', '.join(missing_fields)} to generate the Demo Agreement Pack Brief.")
    st.text_area("Copy-ready Demo Agreement Pack Brief", value=agreement_pack_brief, height=560, label_visibility="collapsed")
    _render_agreement_pack_actions(agreement_pack_brief, disabled=bool(missing_fields))
    st.download_button(
        "Download Demo Agreement Pack Brief",
        agreement_pack_brief,
        file_name=f"{template_id}_demo_agreement_pack_brief.txt",
        disabled=bool(missing_fields),
    )


def _render_app_header() -> None:
    st.markdown(
        """
        <div class="ds-hero">
            <div class="ds-brand-row">
                <span class="ds-wordmark">Docusign</span>
                <span class="ds-pill">IAM Demo Toolkit</span>
            </div>
            <h1>AI Agent Prompt Builder + QA Wizard</h1>
            <p>Generate and optimize AI Agent Prompts.</p>
        </div>
        """,
        unsafe_allow_html=True,
    )


def _render_section_break() -> None:
    st.markdown('<div class="ds-section-break"></div>', unsafe_allow_html=True)


def _render_sidebar_brand() -> None:
    st.markdown(
        """
        <div class="ds-sidebar-brand">
            <div class="ds-sidebar-mark">D</div>
            <div>
                <div class="ds-sidebar-title">Docusign IAM</div>
                <div class="ds-sidebar-subtitle">SC demo workspace</div>
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def _render_prompt_history_sidebar(context: dict[str, Any], generated_prompt: str, missing_fields: list[str]) -> None:
    st.header("Prompt History")
    st.caption("Saved prompts from this session.")

    st.button("New Prompt", on_click=_reset_intake_state, use_container_width=True)
    st.button(
        "Save Current",
        disabled=bool(missing_fields) or not bool(generated_prompt.strip()),
        on_click=_save_history_entry,
        args=(context, generated_prompt),
        use_container_width=True,
    )

    history = st.session_state.get("prompt_history", [])
    if history:
        st.divider()
        for entry in history:
            st.button(
                entry["title"],
                key=f"history_{entry['id']}",
                on_click=_load_history_entry,
                args=(entry,),
                use_container_width=True,
            )
            st.caption(entry["subtitle"])
        st.divider()
        st.button("Clear History", on_click=_clear_prompt_history, use_container_width=True)
    else:
        st.markdown(
            """
            <div class="ds-empty-history">
                Generate a prompt or Gemini brief, then save it here for quick reuse during the session.
            </div>
            """,
            unsafe_allow_html=True,
        )


def _save_history_entry(context: dict[str, Any], artifact: str) -> None:
    history = st.session_state.get("prompt_history", [])
    if history and history[0].get("artifact") == artifact:
        return

    mode = context.get("generation_mode", "Use Prompt Library")
    destination = context.get("output_destination", "Chat")
    artifact_label = _artifact_label(mode, destination)
    customer = context.get("customer_name", "").strip() or "Untitled"
    use_case = context.get("use_case", "").strip() or "Prompt"
    library_title = context.get("library_title", "").strip()
    timestamp = datetime.now().strftime("%I:%M %p").lstrip("0")

    entry = {
        "id": f"{datetime.now().timestamp()}",
        "title": f"{customer} - {library_title or artifact_label}",
        "subtitle": f"{use_case} | {destination} | {timestamp}",
        "artifact": artifact,
        "context": _serializable_context(context),
    }
    st.session_state.prompt_history = [entry, *history][:8]


def _load_history_entry(entry: dict[str, Any]) -> None:
    context = entry.get("context", {})
    st.session_state.loaded_history_entry = entry
    st.session_state.generation_mode = context.get("generation_mode", "Use Prompt Library")
    st.session_state.library_prompt_type = context.get("library_prompt_type", "AI Agent")
    st.session_state.library_category = context.get("library_category", "")
    st.session_state.library_title = context.get("library_title", "")
    st.session_state.existing_prompt = context.get("existing_prompt", "")
    st.session_state.customer_name = context.get("customer_name", "")
    st.session_state.audience = context.get("audience", "")
    st.session_state.contract_type = context.get("contract_type", "")
    st.session_state.industry = context.get("industry", "")
    st.session_state.output_destination = context.get("output_destination", "Chat")
    st.session_state.use_case = context.get("use_case", "")
    st.session_state.document_scope = context.get("document_scope", "")
    st.session_state.agent_objective = context.get("agent_objective", "")
    st.session_state.workflow_data_outputs = "\n".join(context.get("required_fields", []))
    st.session_state.workflow_decision_logic = context.get("decision_logic", "")


def _reset_intake_state() -> None:
    for key in [
        "loaded_history_entry",
        "generation_mode",
        "library_prompt_type",
        "library_category",
        "library_title",
        "existing_prompt",
        "customer_name",
        "audience",
        "contract_type",
        "industry",
        "output_destination",
        "use_case",
        "document_scope",
        "agent_objective",
        "workflow_data_outputs",
        "workflow_decision_logic",
        "validation_report",
    ]:
        st.session_state.pop(key, None)


def _clear_prompt_history() -> None:
    st.session_state.prompt_history = []
    st.session_state.pop("loaded_history_entry", None)


def _artifact_label(mode: str, destination: str) -> str:
    if mode == "Generate with Gemini Agent":
        return "Gemini Brief"
    if mode == "Customize existing prompt":
        return "Customized Prompt"
    if mode == "Use Prompt Library":
        return "Library Prompt"
    return f"{destination} Prompt"


def _serializable_context(context: dict[str, Any]) -> dict[str, Any]:
    return {
        key: value
        for key, value in context.items()
        if isinstance(value, (str, int, float, bool, list, dict)) or value is None
    }


def _prompt_library_form(default_library: list[dict[str, Any]]) -> dict[str, Any]:
    st.subheader("Prompt Library")
    library_entries = default_library

    if not library_entries:
        st.warning("No prompt library entries were found. The app will use the built-in renewal prompt pattern.")
        return {}

    prompt_types = _ordered_unique(entry["prompt_type"] for entry in library_entries)
    prompt_type = st.selectbox(
        "Prompt type",
        prompt_types,
        index=_safe_index(prompt_types, st.session_state.get("library_prompt_type", "AI Agent")),
        key="library_prompt_type",
    )

    type_entries = [entry for entry in library_entries if entry["prompt_type"] == prompt_type]
    categories = _ordered_unique(entry["category"] for entry in type_entries if entry.get("category")) or ["General"]
    category_index = _library_category_index(categories, type_entries, st.session_state.get("library_category", ""))
    category = st.selectbox(
        "Category",
        categories,
        index=category_index,
        key="library_category",
    )

    filtered_entries = [entry for entry in type_entries if entry.get("category") == category]
    if not filtered_entries:
        filtered_entries = type_entries

    titles = [entry.get("title", "Untitled") for entry in filtered_entries]
    saved_title = st.session_state.get("library_title", "")
    title_index = _library_title_index(filtered_entries, saved_title)
    selected_label = st.selectbox("Agent or worksheet name", titles, index=title_index, key="library_title")
    selected_entry = filtered_entries[titles.index(selected_label)]

    _render_library_entry_preview(selected_entry)
    return selected_entry


def _render_library_entry_preview(entry: dict[str, Any]) -> None:
    description = entry.get("description") or "No description provided in the library."
    data_outputs = entry.get("data_outputs") or "No data outputs listed."
    source_prompt = entry.get("prompt") or "No full source prompt listed yet. The app will use the description and data outputs as the starting point."

    st.markdown(
        f"""
        <div class="ds-library-preview">
            <div class="ds-library-kicker">{escape(entry.get('prompt_type', 'Prompt'))} · {escape(entry.get('category', 'General'))}</div>
            <div class="ds-library-title">{escape(entry.get('title', 'Untitled'))}</div>
            <div class="ds-library-body">{escape(description)}</div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    with st.expander("Library prompt details", expanded=False):
        st.markdown("**Starting prompt or question**")
        st.text_area("Starting prompt or question", value=source_prompt, height=180, label_visibility="collapsed", disabled=True)
        st.markdown("**Data outputs / worksheet columns**")
        st.text_area("Data outputs or worksheet columns", value=data_outputs, height=120, label_visibility="collapsed", disabled=True)
        if entry.get("link_to_assets"):
            st.markdown(f"**Link to assets:** {entry['link_to_assets']}")


def _context_form(template: dict[str, Any], rules: dict[str, Any], prompt_library: list[dict[str, Any]]) -> dict[str, Any]:
    defaults = template.get("context_defaults", {})

    st.subheader("Agent Intake Form")
    generation_mode = st.radio(
        "Generation Mode",
        GENERATION_MODES,
        horizontal=True,
        key="generation_mode",
        help="Choose whether to adapt the selected library prompt, adapt a prompt you already like, or create a brief for your Gemini prompt-building agent.",
    )
    existing_prompt = ""
    if generation_mode == "Generate with Gemini Agent":
        st.info(
            "This mode does not connect to Gemini directly. It creates a copy-ready brief for your enterprise Gemini agent using the intake form context."
        )
    elif generation_mode == "Customize existing prompt":
        existing_prompt = st.text_area(
            "Paste a prompt that already works well",
            value="",
            placeholder="Paste the proven prompt you want this app to adapt for the new customer, industry, LOB, use case, and destination.",
            height=220,
            key="existing_prompt",
        )

    left, right = st.columns(2)
    with left:
        customer_name = st.text_input("Customer", value="", placeholder=defaults.get("customer_name", "Acme Software"), key="customer_name")
        audience = st.text_input("LOB", value="", placeholder=defaults.get("audience", "Account team and Sales leadership"), key="audience")
        contract_type = st.text_input("Agreement type", value="", placeholder=defaults.get("contract_type", "Subscription Agreement"), key="contract_type")
        industry = st.text_input("Industry", value="", placeholder=defaults.get("industry", "B2B SaaS"), key="industry")
    with right:
        output_destination = st.selectbox(
            "Where will the agent be used?",
            ALLOWED_OUTPUT_DESTINATIONS,
            index=_safe_index(ALLOWED_OUTPUT_DESTINATIONS, defaults.get("output_destination", "Chat")),
            key="output_destination",
        )
        use_case = st.text_input(
            "Customer / evaluation use case",
            value="",
            placeholder=defaults.get("use_case", template["name"]),
            key="use_case",
            help="Use this for the customer's broader evaluation scenario, not the selected agent or worksheet title.",
        )

    document_scope = st.text_area(
        "What documents or data will the agent be reviewing?",
        value="",
        placeholder=defaults.get("document_scope", "Completed agreement package and available account metadata."),
        height=80,
        key="document_scope",
    )
    agent_objective = st.text_area(
        "What should the agent or worksheet accomplish?",
        value="",
        placeholder=defaults.get(
            "agent_objective",
            defaults.get("business_outcome", "Create a reliable, demo-ready recommendation the business can act on."),
        ),
        height=80,
        key="agent_objective",
    )

    selected_library_entry: dict[str, Any] = {}
    if generation_mode == "Use Prompt Library":
        selected_library_entry = _prompt_library_form(prompt_library)

    library_data_outputs = selected_library_entry.get("data_outputs", "")
    required_fields_default = library_data_outputs or "\n".join(rules["required_fields"])
    decision_logic_default = defaults.get("decision_logic") or _definitions_as_lines(rules)
    if output_destination == "Workflow":
        required_fields = st.text_area(
            "Data Outputs",
            value=required_fields_default,
            height=135,
            key="workflow_data_outputs",
        )
        decision_logic = st.text_area(
            "Decision Logic",
            value=decision_logic_default,
            height=135,
            key="workflow_decision_logic",
        )
    else:
        required_fields = required_fields_default
        decision_logic = decision_logic_default

    required_output_format = _default_output_format(output_destination)

    return {
        "customer_name": customer_name,
        "industry": industry,
        "audience": audience,
        "use_case": use_case,
        "contract_type": contract_type,
        "agent_objective": agent_objective,
        "document_scope": document_scope,
        "output_destination": output_destination,
        "required_output_format": required_output_format,
        "required_fields": _lines(required_fields),
        "decision_logic": decision_logic,
        "risk_tolerance": defaults.get("risk_tolerance", "Balanced"),
        "business_outcome": agent_objective,
        "generation_mode": generation_mode,
        "existing_prompt": existing_prompt,
        "library_prompt_type": selected_library_entry.get("prompt_type", ""),
        "library_category": selected_library_entry.get("category", ""),
        "library_title": selected_library_entry.get("title", ""),
        "library_description": selected_library_entry.get("description", ""),
        "library_prompt": selected_library_entry.get("prompt", ""),
        "library_data_outputs": selected_library_entry.get("data_outputs", ""),
        "library_link_to_assets": selected_library_entry.get("link_to_assets", ""),
        "library_source_sheet": selected_library_entry.get("source_sheet", ""),
    }


def _missing_prompt_fields(context: dict[str, Any]) -> list[str]:
    required_labels = {
        "customer_name": "Customer",
        "audience": "LOB",
        "contract_type": "Agreement type",
        "industry": "Industry",
        "use_case": "Customer / evaluation use case",
        "document_scope": "What documents or data will the agent be reviewing?",
        "agent_objective": "What should the agent or worksheet accomplish?",
    }
    if context.get("generation_mode") == "Customize existing prompt":
        required_labels["existing_prompt"] = "Paste a prompt that already works well"
    return [label for field_name, label in required_labels.items() if not str(context.get(field_name, "")).strip()]


def _default_output_format(output_destination: str) -> str:
    if output_destination in {"Workflow", "Salesforce"}:
        return "JSON"
    return "Plain Language Summary"


def _build_generated_artifact(context: dict[str, Any], template: dict[str, Any], rules: dict[str, Any]) -> str:
    generation_mode = context.get("generation_mode", "Use Prompt Library")
    if generation_mode == "Generate with Gemini Agent":
        return _build_gemini_agent_brief(context, template, rules)
    if generation_mode == "Customize existing prompt":
        return _build_customized_prompt(context, template, rules)
    return build_prompt(context, template, rules)


def _build_customized_prompt(context: dict[str, Any], template: dict[str, Any], rules: dict[str, Any]) -> str:
    base_prompt = context.get("existing_prompt", "").strip()
    generated_guardrails = build_prompt(context, template, rules)

    return f"""Adapted AI Agent Prompt:
Use the proven prompt pattern below, but tailor it to this customer demo context.

Customer context:
- Customer: {context['customer_name']}
- Industry: {context['industry']}
- LOB: {context['audience']}
- Customer / evaluation use case: {context['use_case']}
- Agreement type: {context['contract_type']}
- Agent destination: {context['output_destination']}
- Selected library pattern: {context.get('library_title', 'Not selected')} ({context.get('library_prompt_type', 'Prompt')})

Documents and data reviewed:
{context['document_scope']}

Agent objective:
{context['agent_objective']}

Instructions:
- Preserve the strongest structure, tone, and guardrails from the proven prompt.
- Replace any old customer, industry, LOB, use case, agreement type, objective, or output destination with the context above.
- Keep customer-facing responses concise, deterministic, and demo-ready.
- Do not expose machine field names with underscores unless the destination is Workflow or Salesforce.
- For Workflow or Salesforce, preserve strict field names, allowed values, and routing logic.
- Do not invent agreement terms, dates, commercial values, or source evidence.

Proven prompt to adapt:
{base_prompt}

Required quality bar:
{generated_guardrails}
"""


def _build_gemini_agent_brief(context: dict[str, Any], template: dict[str, Any], rules: dict[str, Any]) -> str:
    output_rules = _library_output_style_instructions(context)
    required_fields = _required_fields_text(context, rules)
    allowed_values = _allowed_values_text(rules, context)
    prompt_type = context.get("library_prompt_type") or "AI Agent"
    library_title = context.get("library_title") or "Net-new prompt from intake context"
    library_category = context.get("library_category") or "Not selected"
    library_description = context.get("library_description") or "Use the intake form context as the starting point."
    library_prompt = context.get("library_prompt", "").strip() or "No source prompt selected; use the intake form context as the starting point."

    return f"""Gemini Agent Brief: Net-New {prompt_type} Prompt

Role:
You are a prompt architect helping a DocuSign Solution Consultant create a customer-ready Docusign IAM prompt for a demo or POC.

Goal:
Generate a net-new prompt for the selected prompt-library pattern and customer scenario below. The prompt should be copy-ready for a Docusign IAM AI chat, agent, workflow, worksheet, or agreement management experience.

Selected prompt-library starting point:
- Type: {prompt_type}
- Category: {library_category}
- Title: {library_title}
- What it does: {library_description}

Source prompt or worksheet question:
{library_prompt}

Customer and demo context:
- Customer: {context['customer_name']}
- Industry: {context['industry']}
- LOB: {context['audience']}
- Customer / evaluation use case: {context['use_case']}
- Agreement type: {context['contract_type']}
- Agent destination: {context['output_destination']}

Documents and data the agent will review:
{context['document_scope']}

Agent objective:
{context['agent_objective']}

Required behavior:
- Write the final AI Agent prompt, not an explanation of the prompt.
- Make it concise, deterministic, and easy for an SC to use in a live customer demo.
- Include clear role, task, evidence, hallucination, missing-information, output, and recommendation instructions.
- Do not include internal implementation notes, schema jargon, or developer-facing language unless the agent destination is Workflow or Salesforce.
- Do not invent agreement terms, dates, renewal rights, commercial values, source evidence, or business facts.
- If source information is missing, instruct the agent to write "Not found in agreement."

Output requirements:
{output_rules}

Data outputs or visible fields:
{required_fields}

Allowed values:
{allowed_values}

Decision logic:
{context['decision_logic']}

Return format:
1. First return only the copy-ready {prompt_type} prompt.
2. Then add a short "What changed" section with no more than 5 bullets explaining the prompt design choices.
"""


def _build_demo_agreement_pack_brief(context: dict[str, Any], rules: dict[str, Any]) -> str:
    data_outputs = _required_fields_text(context, rules)
    allowed_values = _allowed_values_text(rules, context)

    return f"""Demo Agreement Pack Brief: Fictional Executed Agreement Set

Role:
You are creating demo-only source documents for a DocuSign Solution Consultant. The documents must be fictional, safe for customer-facing demos, and designed to produce a clear, compelling AI Agent response when used with the related agent prompt.

Important safety rules:
- Do not use real customer names, real people, real addresses, real signatures, real emails, real phone numbers, or confidential data.
- Mark every document as "Fictional demo document - not legally binding."
- Use realistic contract language, but keep all parties, dates, amounts, products, and clauses fictional.
- Include executed/signature blocks so the documents look like completed agreements.

Demo context:
- Customer/demo account: {context['customer_name']}
- Industry: {context['industry']}
- LOB: {context['audience']}
- Customer / evaluation use case: {context['use_case']}
- Agreement type: {context['contract_type']}
- Agent destination: {context['output_destination']}
- Selected prompt-library pattern: {context.get('library_title', 'Not selected')} ({context.get('library_prompt_type', 'Prompt')})

Documents or data the agent should review:
{context['document_scope']}

Agent objective:
{context['agent_objective']}

Create this demo agreement pack:
1. A primary executed agreement package for {context['contract_type']} between two fictional companies.
2. One supporting order form, statement of work, purchase schedule, renewal notice, amendment, or supplier summary that reinforces the use case.
3. A short metadata sheet with account name, counterparty, effective date, term, owner, business unit, and key commercial values.
4. Optional: one conflicting or missing term that gives the agent a useful but manageable risk to flag.

Design the documents so the agent can produce a demo-ready response with:
- A crisp status or verdict.
- A compact table of key findings.
- One clear business risk or opportunity.
- One short evidence quote from the agreement pack.
- One recommended next action with an owner.

Data outputs or findings the source documents should support:
{data_outputs}

Allowed values to support when applicable:
{allowed_values}

Decision logic to make possible through the source documents:
{context['decision_logic']}

Return format:
1. Start with a one-paragraph summary of the demo scenario.
2. Then generate each fictional document with a clear title.
3. Include realistic clauses and metadata the AI Agent can cite.
4. End with a "Golden path expected findings" section listing the exact facts the agent should be able to extract.
"""


def _render_gemini_mode_steps() -> None:
    st.markdown(
        """
        <div class="ds-steps">
            <div><strong>1.</strong> Complete the Agent Intake Form.</div>
            <div><strong>2.</strong> Copy the Gemini Agent Brief below.</div>
            <div><strong>3.</strong> Open Gemini, paste the brief, and let your enterprise Gemini agent create the net-new prompt.</div>
            <div><strong>4.</strong> Run Gemini's generated prompt, then paste the sample AI Agent output into the QA Wizard.</div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def _render_agreement_pack_steps() -> None:
    st.markdown(
        """
        <div class="ds-steps">
            <div><strong>1.</strong> Complete the Agent Intake Form and generate or adapt the AI Agent prompt.</div>
            <div><strong>2.</strong> Copy the Demo Agreement Pack Brief below.</div>
            <div><strong>3.</strong> Open Gemini or another approved document-generation workspace and paste the brief.</div>
            <div><strong>4.</strong> Use the fictional executed agreements as demo source data, then validate the agent response in the QA Wizard.</div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def _render_gemini_actions(brief: str, disabled: bool) -> None:
    if disabled:
        left, right = st.columns(2)
        left.button("Copy Gemini Agent Brief", disabled=True)
        right.button("Paste in Gemini", disabled=True)
        return

    escaped_brief = json.dumps(brief)
    gemini_url = escape(GEMINI_CHAT_URL, quote=True)
    components.html(
        f"""
        <div class="gemini-actions">
            <button id="copy-brief" type="button">Copy Gemini Agent Brief</button>
            <a id="open-gemini" href="{gemini_url}" target="_blank" rel="noopener noreferrer">Paste in Gemini</a>
            <span id="copy-status" aria-live="polite"></span>
        </div>
        <script>
            const brief = {escaped_brief};
            const copyButton = document.getElementById("copy-brief");
            const status = document.getElementById("copy-status");
            copyButton.addEventListener("click", async () => {{
                try {{
                    await navigator.clipboard.writeText(brief);
                    status.textContent = "Copied. Open Gemini and paste into the new chat.";
                }} catch (error) {{
                    status.textContent = "Copy failed. Select the brief text and copy it manually.";
                }}
            }});
        </script>
        <style>
            .gemini-actions {{
                align-items: center;
                display: flex;
                flex-wrap: wrap;
                gap: 0.75rem;
                padding: 0.2rem 0 0.7rem;
            }}
            .gemini-actions button,
            .gemini-actions a {{
                align-items: center;
                border-radius: 8px;
                box-sizing: border-box;
                cursor: pointer;
                display: inline-flex;
                font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
                font-size: 0.95rem;
                font-weight: 700;
                justify-content: center;
                min-height: 2.55rem;
                padding: 0.55rem 0.95rem;
                text-decoration: none;
            }}
            .gemini-actions button {{
                background: #ffffff;
                border: 1px solid #4c00ff;
                color: #4c00ff;
            }}
            .gemini-actions a {{
                background: #4c00ff;
                border: 1px solid #4c00ff;
                color: #ffffff;
            }}
            .gemini-actions button:hover {{
                border-color: #26065d;
                color: #26065d;
            }}
            .gemini-actions a:hover {{
                background: #26065d;
                border-color: #26065d;
            }}
            #copy-status {{
                color: #5f5577;
                font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
                font-size: 0.9rem;
            }}
        </style>
        """,
        height=72,
    )


def _render_agreement_pack_actions(brief: str, disabled: bool) -> None:
    if disabled:
        left, right = st.columns(2)
        left.button("Copy Demo Agreement Pack Brief", disabled=True)
        right.button("Paste in Gemini", disabled=True)
        return

    escaped_brief = json.dumps(brief)
    gemini_url = escape(GEMINI_CHAT_URL, quote=True)
    components.html(
        f"""
        <div class="gemini-actions">
            <button id="copy-agreement-pack-brief" type="button">Copy Demo Agreement Pack Brief</button>
            <a id="open-gemini-agreement-pack" href="{gemini_url}" target="_blank" rel="noopener noreferrer">Paste in Gemini</a>
            <span id="copy-agreement-pack-status" aria-live="polite"></span>
        </div>
        <script>
            const agreementPackBrief = {escaped_brief};
            const copyAgreementPackButton = document.getElementById("copy-agreement-pack-brief");
            const agreementPackStatus = document.getElementById("copy-agreement-pack-status");
            copyAgreementPackButton.addEventListener("click", async () => {{
                try {{
                    await navigator.clipboard.writeText(agreementPackBrief);
                    agreementPackStatus.textContent = "Copied. Open Gemini and paste into the new chat.";
                }} catch (error) {{
                    agreementPackStatus.textContent = "Copy failed. Select the brief text and copy it manually.";
                }}
            }});
        </script>
        <style>
            .gemini-actions {{
                align-items: center;
                display: flex;
                flex-wrap: wrap;
                gap: 0.75rem;
                padding: 0.2rem 0 0.7rem;
            }}
            .gemini-actions button,
            .gemini-actions a {{
                align-items: center;
                border-radius: 8px;
                box-sizing: border-box;
                cursor: pointer;
                display: inline-flex;
                font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
                font-size: 0.95rem;
                font-weight: 700;
                justify-content: center;
                min-height: 2.55rem;
                padding: 0.55rem 0.95rem;
                text-decoration: none;
            }}
            .gemini-actions button {{
                background: #ffffff;
                border: 1px solid #4c00ff;
                color: #4c00ff;
            }}
            .gemini-actions a {{
                background: #4c00ff;
                border: 1px solid #4c00ff;
                color: #ffffff;
            }}
            .gemini-actions button:hover {{
                border-color: #26065d;
                color: #26065d;
            }}
            .gemini-actions a:hover {{
                background: #26065d;
                border-color: #26065d;
            }}
            #copy-agreement-pack-status {{
                color: #5f5577;
                font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
                font-size: 0.9rem;
            }}
        </style>
        """,
        height=72,
    )


def _render_output_rules(rules: dict[str, Any], context: dict[str, Any]) -> None:
    st.markdown("The app uses these rules quietly when generating and testing the prompt.")
    if context["required_output_format"] != "JSON" and context["output_destination"] != "Workflow":
        limits = rules.get("customer_output_limits", {})
        if limits:
            st.markdown(
                "\n".join(
                    [
                        f"- Keep customer-facing responses under {limits.get('max_words', 180)} words.",
                        f"- Use no more than {limits.get('max_table_rows', 8)} table rows.",
                        "- Use readable labels, not underscore field names.",
                    ]
                )
            )
    if rules.get("allowed_values"):
        st.markdown("**Allowed result values**")
        for field_name, values in rules["allowed_values"].items():
            st.markdown(f"- {_human_label(field_name)}: {', '.join(values)}")


def _qa_wizard(template_id: str, context: dict[str, Any], generated_prompt: str, rules: dict[str, Any]) -> None:
    if not _uses_renewal_validator(context):
        _generic_qa_wizard(context, generated_prompt)
        return

    st.subheader("Validate Sample AI Agent / Worksheet Output")
    passing_sample_path, failing_sample_path = _sample_paths(rules, {"context_defaults": context})
    sample_left, sample_right = st.columns(2)
    if passing_sample_path.exists() and sample_left.button("Use passing sample"):
        st.session_state.sample_output = passing_sample_path.read_text()
        st.session_state.sample_template_id = template_id
        st.session_state.selected_format = context["required_output_format"]
    if failing_sample_path.exists() and sample_right.button("Use failing sample"):
        st.session_state.sample_output = failing_sample_path.read_text()
        st.session_state.sample_template_id = template_id
        st.session_state.selected_format = context["required_output_format"]

    uploaded = st.file_uploader("Upload sample output", type=["json", "md", "txt", "html", "htm"])
    if uploaded is not None:
        sample_output = uploaded.read().decode("utf-8")
    else:
        sample_output = _default_sample_text(template_id, passing_sample_path)

    output_format = st.selectbox(
        "Sample output format",
        ALLOWED_OUTPUT_FORMATS,
        index=_safe_index(ALLOWED_OUTPUT_FORMATS, st.session_state.get("selected_format", context["required_output_format"])),
        key="selected_format",
    )
    sample_output = st.text_area("Paste sample AI Agent output", value=sample_output, height=340)

    if st.button("Validate output", type="primary"):
        structural = validate_output(sample_output, output_format, rules)
        quality = score_business_quality(
            structural.parsed_output,
            sample_output,
            context["audience"],
            context["output_destination"],
            rules,
        )
        recommendations = recommend_prompt_improvements(
            structural.issues,
            quality.issues,
            context["audience"],
            context["output_destination"],
        )
        optimized_prompt = build_optimized_prompt(generated_prompt, recommendations, context["output_destination"])
        overall_status = determine_status(structural.passed, quality.average_score)

        st.session_state.validation_report = {
            "overall_status": overall_status,
            "structural": structural,
            "quality": quality,
            "recommendations": recommendations,
            "optimized_prompt": optimized_prompt,
            "template_id": template_id,
        }

    report = st.session_state.get("validation_report")
    if report and report.get("template_id") == template_id:
        _render_report(report)


def _uses_renewal_validator(context: dict[str, Any]) -> bool:
    title = context.get("library_title", "").lower()
    prompt_type = context.get("library_prompt_type", "")
    return prompt_type == "AI Agent" and "renewal" in title


def _generic_qa_wizard(context: dict[str, Any], generated_prompt: str) -> None:
    st.subheader("Review Sample AI Agent / Worksheet Output")
    st.info(
        "This selected library pattern uses the general demo-readiness QA check. Renewal intelligence prompts still use the deeper field-by-field validator."
    )
    uploaded = st.file_uploader("Upload sample output", type=["json", "md", "txt", "html", "htm"], key="generic_qa_upload")
    if uploaded is not None:
        sample_output = uploaded.read().decode("utf-8")
    else:
        sample_output = ""
    sample_output = st.text_area("Paste sample AI Agent / Worksheet output", value=sample_output, height=340)

    if st.button("Validate output", type="primary", key="generic_validate_output"):
        st.session_state.generic_validation_report = _generic_quality_report(sample_output, context, generated_prompt)

    report = st.session_state.get("generic_validation_report")
    if report:
        _render_generic_report(report)


def _generic_quality_report(sample_output: str, context: dict[str, Any], generated_prompt: str) -> dict[str, Any]:
    text = sample_output.strip()
    issues: list[str] = []
    strengths: list[str] = []
    recommendations: list[str] = []
    word_count = len(text.split())

    if not text:
        issues.append("No sample output was provided.")
    if text and word_count < 35:
        issues.append("The sample output is too thin for a customer-facing demo.")
    if word_count > 260 and context["output_destination"] == "Chat":
        issues.append("The sample output may be too long to speak to comfortably in a live demo.")
    if context["output_destination"] == "Chat" and text.startswith("{"):
        issues.append("The sample output appears to be raw JSON, which is not ideal for a chat demo.")
    if context["output_destination"] not in {"Workflow", "Salesforce"} and "_" in text:
        issues.append("The sample output includes underscore-style field names; use readable labels for customer-facing demos.")
    if text and not any(keyword in text.lower() for keyword in ["action", "next step", "recommend", "route", "owner"]):
        issues.append("The sample output should include a clear next action, owner, or recommendation.")
    if text and not any(keyword in text.lower() for keyword in ["agreement", "contract", "source", "evidence", "clause", "data"]):
        issues.append("The sample output should make the source data or agreement evidence clearer.")

    data_outputs = context.get("required_fields", [])
    if text and data_outputs:
        visible_output_count = sum(1 for field in data_outputs[:8] if field.lower().replace("_", " ") in text.lower())
        if visible_output_count == 0:
            issues.append("The sample output does not clearly reflect the selected Data Outputs or worksheet columns.")
        else:
            strengths.append("The output reflects at least one selected Data Output or worksheet column.")

    if text and not issues:
        strengths.append("The output is concise, structured, and demo-ready.")
    if text and word_count <= 260:
        strengths.append("The output length is reasonable for a live demo.")

    if issues:
        recommendations = [
            "Tighten the prompt so the response is concise, structured, and easy to explain live.",
            "Explicitly ask for readable labels and no underscore-style field names for customer-facing output.",
            "Require one next action, owner, or recommendation.",
            "Ask the agent to cite the agreement, record, clause, or data source it used.",
        ]
    else:
        recommendations = ["No major changes needed. Retest once with the final demo source data."]

    if not text:
        status = "FAIL"
    elif len(issues) <= 1:
        status = "PASS"
    elif len(issues) <= 3:
        status = "NEEDS OPTIMIZATION"
    else:
        status = "FAIL"

    optimized_prompt = build_optimized_prompt(generated_prompt, recommendations, context["output_destination"])
    return {
        "status": status,
        "issues": issues,
        "strengths": strengths,
        "recommendations": recommendations,
        "optimized_prompt": optimized_prompt,
    }


def _render_generic_report(report: dict[str, Any]) -> None:
    status = report["status"]
    status_type = {"PASS": "success", "NEEDS OPTIMIZATION": "warning", "FAIL": "error"}[status]
    getattr(st, status_type)(f"Overall status: {status}")

    col1, col2 = st.columns(2)
    col1.metric("Demo-readiness checks", "Pass" if status == "PASS" else "Review")
    col2.metric("Issue count", len(report["issues"]))

    if report["strengths"]:
        st.subheader("What Looks Good")
        for strength in report["strengths"]:
            st.markdown(f"- {strength}")

    if report["issues"]:
        st.subheader("Issues To Fix")
        for issue in report["issues"]:
            st.markdown(f"- {issue}")

    st.subheader("Recommended Prompt Improvements")
    for recommendation in report["recommendations"]:
        st.markdown(f"- {recommendation}")

    st.subheader("Optimized Prompt Version")
    st.text_area("Optimized prompt", value=report["optimized_prompt"], height=420, label_visibility="collapsed")


def _render_report(report: dict[str, Any]) -> None:
    status = report["overall_status"]
    structural = report["structural"]
    quality = report["quality"]
    recommendations = report["recommendations"]
    optimized_prompt = report["optimized_prompt"]

    status_type = {"PASS": "success", "NEEDS OPTIMIZATION": "warning", "FAIL": "error"}[status]
    getattr(st, status_type)(f"Overall status: {status}")

    col1, col2, col3 = st.columns(3)
    col1.metric("Structural checks", "Pass" if structural.passed else "Fail")
    col2.metric("Business-quality score", f"{quality.average_score} / 5")
    col3.metric("Issue count", len(structural.issues) + len(quality.issues))

    st.subheader("Structural Validation Results")
    if structural.issues:
        for issue in structural.issues:
            icon = "Error" if issue.severity == "error" else "Warning"
            st.markdown(f"**{icon}: `{issue.field}`**  \n{issue.message}  \nFix: {issue.fix_hint}")
    else:
        st.write("All required structural checks passed.")

    st.subheader("Business-Quality Score")
    st.dataframe(
        [{"Category": category, "Score": score} for category, score in quality.category_scores.items()],
        hide_index=True,
        width="stretch",
    )
    if quality.issues:
        st.markdown("**Quality issues**")
        for issue in quality.issues:
            st.markdown(f"- {issue}")

    st.subheader("Recommended Prompt Improvements")
    for recommendation in recommendations:
        st.markdown(f"- {recommendation}")

    st.subheader("Optimized Prompt Version")
    st.text_area("Optimized prompt", value=optimized_prompt, height=420, label_visibility="collapsed")

    st.subheader("Retest Checklist")
    for item in _retest_checklist():
        st.checkbox(item, value=False)


def build_prompt(context: dict[str, Any], template: dict[str, Any], rules: dict[str, Any]) -> str:
    if context.get("library_title"):
        return _build_library_prompt(context, rules)

    if context["required_output_format"] != "JSON" and context["output_destination"] != "Workflow":
        return _build_customer_demo_prompt(context, template, rules)

    required_fields = _required_fields_text(context, rules)
    allowed_values = _allowed_values_text(rules, context)
    definitions = _definitions_text(rules)
    analysis_instructions = _bullets(rules.get("analysis_instructions", []))
    extraction_instructions = _bullets(rules.get("extraction_instructions", []))
    routing_logic = _bullets(rules.get("routing_logic", []))
    recommendation_requirements = _bullets(rules.get("recommendation_requirements", []))
    output_style = _output_style_instructions(context)
    example_output = _example_output_text(context, template)
    checklist = _bullets(template.get("validation_checklist", []))
    recommendation_schema_instruction = _recommended_action_instruction(context)

    return f"""Agent role:
You specialize in {template['name']} use cases where completed agreement language must be converted into structured, actionable business intelligence.

Agent objective:
{context['agent_objective']}

Customer context:
- Customer: {context['customer_name']}
- Industry: {context['industry']}
- Customer / evaluation use case: {context['use_case']}
- Contract type: {context['contract_type']}
- Risk tolerance: {context['risk_tolerance']}

LOB:
{context['audience']}

Documents and data reviewed:
{context['document_scope']}

Input assumptions:
- Analyze only the agreement language, metadata, and business context provided in the current request.
- Do not invent contract terms.
- Use extracted agreement language where available.
- If a required term is not found, return "Not found in agreement."
- Return all required fields even when some values are missing.

Analysis instructions:
{analysis_instructions}

Allowed values:
{allowed_values}

Definitions:
{definitions}

Extraction instructions:
{extraction_instructions}

Decision logic:
{context['decision_logic']}

Required output format:
{context['required_output_format']} for {context['output_destination']}.
If the output is intended for Workflow, use strict field names and allowed values only.

Output instructions:
{output_style}

Required fields or variables:
{required_fields}

Guardrails against hallucination:
- Do not invent contract terms, clause names, renewal dates, notice windows, payment terms, uplift rights, renewal rights, termination rights, or commercial values.
- Do not infer missing terms unless the agreement language or supplied metadata supports the inference.
- Use extracted agreement language where available.
- If source language is missing, return "Not found in agreement."

Instructions for missing information:
- Keep the field present.
- Use "Not found in agreement" for missing agreement language.
- Explain business impact only when the provided agreement language supports it.

Escalation/routing logic:
{routing_logic}

Recommendation requirements:
{recommendation_requirements}
- Make recommendations specific and actionable.
- Avoid generic statements like "manual review required" unless paired with rationale and next step.
{recommendation_schema_instruction}

Example good output:
{example_output}

Validation checklist:
{checklist}
"""


def _build_library_prompt(context: dict[str, Any], rules: dict[str, Any]) -> str:
    if context.get("library_prompt_type") == "Worksheet":
        return _build_library_worksheet_prompt(context)
    return _build_library_agent_prompt(context, rules)


def _build_library_agent_prompt(context: dict[str, Any], rules: dict[str, Any]) -> str:
    source_prompt = context.get("library_prompt", "").strip()
    source_prompt_section = source_prompt or "No full source prompt is listed in the library. Use the agent title, description, objective, and data outputs below as the operating pattern."

    return f"""Agent role:
You are the {context['library_title']} for Docusign IAM.

Selected library pattern:
- Category: {context['library_category']}
- Agent title: {context['library_title']}
- What the agent does: {context['library_description'] or 'Not provided'}

Customer and evaluation context:
- Customer: {context['customer_name']}
- Industry: {context['industry']}
- LOB: {context['audience']}
- Customer / evaluation use case: {context['use_case']}
- Agreement type: {context['contract_type']}
- Agent destination: {context['output_destination']}

Documents and data reviewed:
{context['document_scope']}

Agent objective:
{context['agent_objective']}

Operating pattern from the prompt library:
{source_prompt_section}

Required agent behavior:
- Use the operating pattern above, but tailor the response to the customer and evaluation context.
- Produce a concise, deterministic, well-formatted response that is easy to speak to in a live demo.
- Prioritize the user-requested business outcome over exhaustive analysis.
- Use customer-facing language unless the destination is Workflow or Salesforce.
- Do not invent agreement terms, account data, commercial values, source evidence, or business facts.
- If source information is missing, write "Not found in agreement" or "Not available in the provided data."

Output requirements:
{_library_output_style_instructions(context)}

Data outputs or visible fields:
{_required_fields_text(context, rules)}

Decision logic:
{context['decision_logic']}
"""


def _build_library_worksheet_prompt(context: dict[str, Any]) -> str:
    worksheet_question = context.get("library_prompt", "").strip() or context["agent_objective"]
    worksheet_columns = context.get("library_data_outputs", "").strip() or "Use the most relevant columns for the requested analysis."

    return f"""Worksheet prompt:
Create an AI-generated worksheet in Docusign IAM for the selected customer and evaluation scenario.

Worksheet pattern:
- Worksheet name: {context['library_title']}
- Persona / category: {context['library_category']}
- Source question: {worksheet_question}

Customer and evaluation context:
- Customer: {context['customer_name']}
- Industry: {context['industry']}
- LOB: {context['audience']}
- Customer / evaluation use case: {context['use_case']}
- Agreement type: {context['contract_type']}

Documents and data to review:
{context['document_scope']}

Worksheet objective:
{context['agent_objective']}

Required columns:
{worksheet_columns}

Instructions:
- Create a practical worksheet the {context['audience']} team can use in a demo.
- Use one row per relevant agreement, supplier, counterparty, obligation, account, or record depending on the selected worksheet pattern.
- Use only available agreement text, metadata, and connected business data.
- Do not invent contract terms, dates, obligations, commercial values, counterparties, or source evidence.
- If a value cannot be found, write "Not found in agreement" or "Not available in the provided data."
- Keep column names readable for a business audience.
- Make the worksheet output concise, structured, and demo-ready.
"""


def _build_customer_demo_prompt(context: dict[str, Any], template: dict[str, Any], rules: dict[str, Any]) -> str:
    allowed_values = _allowed_values_text(rules, context)
    visible_fields = _required_fields_text(context, rules)
    example_output = _example_output_text(context, template)

    return f"""Agent role:
You specialize in completed agreement renewal intelligence. Turn agreement evidence into a concise, customer-facing renewal brief.

Agent objective:
{context['agent_objective']}

LOB:
{context['audience']}

Documents and data reviewed:
{context['document_scope']}

Required response contract:
- Return a demo brief, not a full analysis report.
- Use exactly this structure: title, one-line verdict, compact table, why it matters, evidence, recommended action.
- Keep the entire response under 180 words.
- Include at most 8 table rows, 1 risk, 1 evidence quote, and 1 recommended action.
- Use customer-facing labels such as `Agreement name`; do not show underscores.
- Do not return JSON unless the user explicitly asks for JSON.
- Make every sentence speakable in a live demo.

Visible fields:
{visible_fields}

Allowed values:
{allowed_values}

Evidence and hallucination rules:
- Do not invent contract terms, dates, notice windows, renewal rights, uplift terms, or commercial values.
- Use extracted agreement language where available.
- Quote only the shortest useful evidence excerpt.
- If a required term is missing, write "Not found in agreement."

Example output:
{example_output}
"""


def build_expected_schema(rules: dict[str, Any]) -> dict[str, Any]:
    if rules.get("expected_schema"):
        return rules["expected_schema"]
    return {field_name: "string" for field_name in rules["required_fields"]}


def determine_status(structural_passed: bool, quality_score: float) -> str:
    if not structural_passed:
        return "FAIL"
    if quality_score >= 4:
        return "PASS"
    return "NEEDS OPTIMIZATION"


def _load_yaml(path: Path) -> dict[str, Any]:
    return yaml.safe_load(path.read_text())


def _load_rules(template_id: str, template: dict[str, Any]) -> dict[str, Any]:
    rules_path = RULES_DIR / f"{template_id}_rules.yaml"
    if rules_path.exists():
        return _load_yaml(rules_path)
    return {
        "template_id": template_id,
        "required_fields": template.get("default_required_fields", []),
        "allowed_values": {},
        "missing_information_phrase": "Not found in agreement",
        "sample_files": {},
    }


def _load_default_prompt_library() -> list[dict[str, Any]]:
    if not PROMPT_LIBRARY_PATH.exists():
        return []
    return _load_prompt_library_from_bytes(PROMPT_LIBRARY_PATH.read_bytes())


@st.cache_data(show_spinner=False)
def _load_prompt_library_from_bytes(workbook_bytes: bytes) -> list[dict[str, Any]]:
    sheets = _read_xlsx_sheets(workbook_bytes)
    entries: list[dict[str, Any]] = []
    entries.extend(_ai_agent_entries(sheets.get("AI Agents", [])))
    entries.extend(_worksheet_entries(sheets.get("Worksheets", [])))
    return entries


def _read_xlsx_sheets(workbook_bytes: bytes) -> dict[str, list[list[str]]]:
    namespaces = {
        "main": "http://schemas.openxmlformats.org/spreadsheetml/2006/main",
        "rel": "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
    }

    with zipfile.ZipFile(BytesIO(workbook_bytes)) as workbook:
        shared_strings = _xlsx_shared_strings(workbook, namespaces)
        sheet_paths = _xlsx_sheet_paths(workbook, namespaces)
        sheets: dict[str, list[list[str]]] = {}

        for sheet_name, sheet_path in sheet_paths.items():
            sheet_xml = ET.fromstring(workbook.read(sheet_path))
            rows: list[list[str]] = []
            for row in sheet_xml.findall(".//main:sheetData/main:row", namespaces):
                values_by_index: dict[int, str] = {}
                max_index = -1
                for cell in row.findall("main:c", namespaces):
                    index = _xlsx_column_index(cell.attrib.get("r", ""))
                    max_index = max(max_index, index)
                    values_by_index[index] = _xlsx_cell_value(cell, shared_strings, namespaces).strip()
                if max_index >= 0:
                    values = [values_by_index.get(index, "") for index in range(max_index + 1)]
                    if any(value for value in values):
                        rows.append(values)
            sheets[sheet_name] = rows

    return sheets


def _xlsx_shared_strings(workbook: zipfile.ZipFile, namespaces: dict[str, str]) -> list[str]:
    if "xl/sharedStrings.xml" not in workbook.namelist():
        return []
    shared_xml = ET.fromstring(workbook.read("xl/sharedStrings.xml"))
    return ["".join(item.itertext()) for item in shared_xml.findall("main:si", namespaces)]


def _xlsx_sheet_paths(workbook: zipfile.ZipFile, namespaces: dict[str, str]) -> dict[str, str]:
    workbook_xml = ET.fromstring(workbook.read("xl/workbook.xml"))
    rels_xml = ET.fromstring(workbook.read("xl/_rels/workbook.xml.rels"))
    rel_map = {rel.attrib["Id"]: rel.attrib["Target"] for rel in rels_xml}
    sheet_paths: dict[str, str] = {}

    for sheet in workbook_xml.findall(".//main:sheet", namespaces):
        rel_id = sheet.attrib.get("{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id")
        target = rel_map.get(rel_id, "")
        if not target:
            continue
        sheet_path = "xl/" + target.lstrip("/") if not target.startswith("xl/") else target
        sheet_paths[sheet.attrib["name"]] = sheet_path

    return sheet_paths


def _xlsx_column_index(cell_ref: str) -> int:
    letters = "".join(character for character in cell_ref if character.isalpha())
    index = 0
    for character in letters:
        index = index * 26 + (ord(character.upper()) - 64)
    return max(index - 1, 0)


def _xlsx_cell_value(cell: ET.Element, shared_strings: list[str], namespaces: dict[str, str]) -> str:
    cell_type = cell.attrib.get("t")
    if cell_type == "s":
        value = cell.find("main:v", namespaces)
        if value is None or value.text is None:
            return ""
        shared_index = int(value.text)
        return shared_strings[shared_index] if shared_index < len(shared_strings) else ""
    if cell_type == "inlineStr":
        inline_string = cell.find("main:is", namespaces)
        return "".join(inline_string.itertext()) if inline_string is not None else ""
    value = cell.find("main:v", namespaces)
    return value.text if value is not None and value.text is not None else ""


def _ai_agent_entries(rows: list[list[str]]) -> list[dict[str, Any]]:
    entries: list[dict[str, Any]] = []
    current_category = ""
    for row in rows[1:]:
        category = _clean_library_category(_cell(row, 0) or current_category)
        current_category = category or current_category
        title = _cell(row, 1)
        if not title:
            continue
        entries.append(
            {
                "prompt_type": "AI Agent",
                "source_sheet": "AI Agents",
                "category": category or "General",
                "title": title,
                "description": _cell(row, 2),
                "prompt": _cell(row, 3),
                "data_outputs": _cell(row, 4),
                "link_to_assets": _cell(row, 5),
            }
        )
    return entries


def _worksheet_entries(rows: list[list[str]]) -> list[dict[str, Any]]:
    entries: list[dict[str, Any]] = []
    for row in rows[1:]:
        title = _cell(row, 0)
        if not title:
            continue
        persona = _cell(row, 1)
        category = _clean_library_category(persona) or "Worksheet"
        entries.append(
            {
                "prompt_type": "Worksheet",
                "source_sheet": "Worksheets",
                "category": category,
                "title": title,
                "description": f"Persona: {persona}" if persona else "",
                "prompt": _cell(row, 2),
                "data_outputs": _cell(row, 3),
                "link_to_assets": _cell(row, 4),
            }
        )
    return entries


def _cell(row: list[str], index: int) -> str:
    return row[index].strip() if index < len(row) and isinstance(row[index], str) else ""


def _ordered_unique(values: Any) -> list[str]:
    ordered: list[str] = []
    seen: set[str] = set()
    for value in values:
        normalized = _library_dedupe_key(value)
        if value and normalized not in seen:
            ordered.append(value)
            seen.add(normalized)
    return ordered


def _clean_library_category(value: str) -> str:
    return " ".join(value.split())


def _library_dedupe_key(value: str) -> str:
    return _clean_library_category(str(value)).lower()


def _library_category_index(categories: list[str], entries: list[dict[str, Any]], saved_category: str) -> int:
    saved_key = _library_dedupe_key(saved_category)
    for index, category in enumerate(categories):
        if _library_dedupe_key(category) == saved_key:
            return index
    for index, category in enumerate(categories):
        if any(
            _library_dedupe_key(entry.get("category", "")) == _library_dedupe_key(category)
            and DEFAULT_LIBRARY_TITLE_HINT.lower() in entry.get("title", "").lower()
            for entry in entries
        ):
            return index
    return 0


def _library_title_index(entries: list[dict[str, Any]], saved_label_or_title: str) -> int:
    if saved_label_or_title:
        for index, entry in enumerate(entries):
            if saved_label_or_title == entry.get("title", ""):
                return index
    for index, entry in enumerate(entries):
        if DEFAULT_LIBRARY_TITLE_HINT.lower() in entry.get("title", "").lower():
            return index
    return 0


def _sample_paths(rules: dict[str, Any], template_or_context: dict[str, Any]) -> tuple[Path, Path]:
    sample_files = rules.get("sample_files", {})
    defaults = template_or_context.get("context_defaults", template_or_context)
    output_format = defaults.get("required_output_format", "Plain Language Summary")
    if output_format == "JSON":
        passing_key, failing_key = "passing", "failing"
    else:
        passing_key, failing_key = "passing_plain", "failing_plain"
    passing = ROOT / sample_files.get(passing_key, sample_files.get("passing", "samples/completed_agreements_renewal_passing_output.json"))
    failing = ROOT / sample_files.get(failing_key, sample_files.get("failing", "samples/completed_agreements_renewal_failing_output.json"))
    return passing, failing


def _default_sample_text(template_id: str, passing_sample_path: Path) -> str:
    if st.session_state.get("sample_template_id") == template_id and st.session_state.get("sample_output"):
        return st.session_state.sample_output
    if passing_sample_path.exists():
        return passing_sample_path.read_text()
    return ""


def _first_active_template_id(templates: dict[str, Any]) -> str:
    for template_id, template in templates.items():
        if template.get("status") == "active":
            return template_id
    return next(iter(templates))


def _safe_index(options: list[str], selected: str) -> int:
    return options.index(selected) if selected in options else 0


def _lines(value: str) -> list[str]:
    return [line.strip().lstrip("- ").strip() for line in value.splitlines() if line.strip()]


def _bullets(items: list[str]) -> str:
    if not items:
        return "- Follow the required output schema exactly."
    return "\n".join(f"- {item}" for item in items)


def _allowed_values_text(rules: dict[str, Any], context: dict[str, Any]) -> str:
    if not rules.get("allowed_values"):
        return "- No template-specific allowed values configured."
    return "\n".join(f"- {_display_field_name(field_name, context)}: {', '.join(values)}" for field_name, values in rules["allowed_values"].items())


def _definitions_text(rules: dict[str, Any]) -> str:
    definitions = rules.get("status_definitions") or rules.get("triage_definitions") or {}
    if not definitions:
        return "- No template-specific definitions configured."
    return "\n".join(f"- {key}: {value}" for key, value in definitions.items())


def _definitions_as_lines(rules: dict[str, Any]) -> str:
    definitions = rules.get("status_definitions") or rules.get("triage_definitions") or {}
    return "\n".join(f"{key} = {value}" for key, value in definitions.items())


def _library_output_style_instructions(context: dict[str, Any]) -> str:
    if context["required_output_format"] == "JSON" or context["output_destination"] == "Workflow":
        return "\n".join(
            [
                "- Return strict JSON only when this prompt is used for workflow automation.",
                "- Use exact field names and allowed values when workflow variables are configured.",
                "- Do not wrap JSON in markdown fences.",
            ]
        )
    if context.get("library_prompt_type") == "Worksheet":
        return "\n".join(
            [
                "- Create a worksheet-style output using the required columns listed below.",
                "- Keep column names readable for a business audience.",
                "- Use one row per relevant record, agreement, supplier, counterparty, obligation, or account.",
            ]
        )
    return "\n".join(
        [
            "- Follow the output format specified in the selected prompt-library pattern.",
            "- If the library pattern does not specify a format, use a concise business-ready summary or table.",
            "- Do not return raw JSON unless the user, Workflow, or Salesforce destination requires it.",
            "- Use readable labels; do not show underscores in table titles, chart labels, headings, or field labels.",
            "- Keep the response focused enough for an SC to explain in a live demo.",
        ]
    )


def _output_style_instructions(context: dict[str, Any]) -> str:
    output_format = context["required_output_format"]
    destination = context["output_destination"]
    if output_format == "JSON" or destination == "Workflow":
        return "\n".join(
            [
                "- Return strict JSON only.",
                "- Do not wrap JSON in markdown fences.",
                "- Use exact field names and allowed values.",
            ]
        )
    if output_format == "Markdown Table":
        return "\n".join(
            [
                "- Do not return raw JSON.",
                "- Produce a demo brief, not a full analysis report.",
                "- Keep the response under 180 words.",
                "- Use exactly this structure: title, one-line verdict, compact table, why it matters, evidence, recommended action.",
                "- Include at most 8 table rows, 1 risk, 1 evidence quote, and 1 recommended action.",
                "- Use customer-facing labels such as `Agreement name`.",
                "- Do not show underscores in table titles, chart labels, headings, or field labels.",
                "- Make every sentence speakable in a live demo.",
            ]
        )
    if output_format == "Plain Language Summary" or destination == "Chat":
        return "\n".join(
            [
                "- Do not return raw JSON.",
                "- Produce a demo brief, not a full analysis report.",
                "- Keep the response under 180 words.",
                "- Use exactly this structure: title, one-line verdict, compact table, why it matters, evidence, recommended action.",
                "- Include at most 8 table rows, 1 risk, 1 evidence quote, and 1 recommended action.",
                "- Use customer-facing labels such as `Agreement name`.",
                "- Do not show underscores in table titles, chart labels, headings, or field labels.",
                "- Lead with the renewal status, date pressure, and action.",
                "- Quote only the shortest evidence excerpt needed to support the finding.",
                "- Make every sentence speakable in a live demo.",
            ]
        )
    return "- Return a clear, structured response that covers every required field."


def _example_output_text(context: dict[str, Any], template: dict[str, Any]) -> str:
    if context["required_output_format"] == "JSON" or context["output_destination"] == "Workflow":
        return "```json\n" + json.dumps(template["good_output_example"], indent=2) + "\n```"
    chat_example = template.get("chat_output_example")
    if chat_example:
        return chat_example.rstrip()
    return json.dumps(template["good_output_example"], indent=2)


def _recommended_action_instruction(context: dict[str, Any]) -> str:
    if context["required_output_format"] == "JSON" or context["output_destination"] == "Workflow":
        return "- Include action, owner, rationale, and next_step in recommended_action."
    return "- Include a recommended action with an action, owner, rationale, and next step."


def _required_fields_text(context: dict[str, Any], rules: dict[str, Any]) -> str:
    if context.get("library_data_outputs"):
        return "\n".join(f"- {_display_field_name(field, context)}" for field in context["required_fields"])
    if context["required_output_format"] == "JSON" or context["output_destination"] == "Workflow":
        return "\n".join(f"- {field}" for field in context["required_fields"])
    customer_fields = rules.get("customer_facing_required_fields", context["required_fields"])
    return "\n".join(f"- {_human_label(field)}" for field in customer_fields)


def _display_field_name(field_name: str, context: dict[str, Any]) -> str:
    if context["required_output_format"] == "JSON" or context["output_destination"] == "Workflow":
        return field_name
    return _human_label(field_name)


def _human_label(field_name: str) -> str:
    if "_" not in field_name:
        return field_name
    acronyms = {"arr": "ARR"}
    words = field_name.split("_")
    formatted = [acronyms.get(word, word) for word in words]
    if not formatted:
        return field_name
    first = formatted[0].capitalize()
    return " ".join([first, *formatted[1:]])


def _retest_checklist() -> list[str]:
    return [
        "Rerun the AI Agent with the optimized prompt.",
        "Confirm every required field is returned.",
        "Confirm allowed values are exact and workflow-safe.",
        "Confirm renewal or risk items include extracted agreement language.",
        "Confirm missing terms are marked as Not found in agreement.",
        "Confirm the recommendation has an owner, rationale, and next step.",
    ]


def _inject_styles() -> None:
    st.markdown(
        """
        <style>
        :root {
            --ds-cobalt: #4c00ff;
            --ds-inkwell: #130032;
            --ds-deep-violet: #26065d;
            --ds-mist: #cbc2ff;
            --ds-poppy: #ff5252;
            --ds-ecru: #f8f3f0;
            --ds-white: #ffffff;
            --ds-border: #e7e2f6;
            --ds-muted: #5f5577;
            --ds-soft-shadow: 0 18px 42px rgba(19, 0, 50, 0.08);
        }

        .stApp {
            background:
                linear-gradient(180deg, rgba(248, 243, 240, 0.9) 0%, rgba(255, 255, 255, 0.96) 32%, #ffffff 100%);
            color: var(--ds-inkwell);
            font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
        }

        div[data-testid="stHeader"] {
            background: rgba(248, 243, 240, 0.88);
            border-bottom: 1px solid rgba(203, 194, 255, 0.42);
            backdrop-filter: blur(12px);
        }

        div[data-testid="stAppViewContainer"] > .main {
            background: transparent;
        }

        .main .block-container {
            max-width: 1240px;
            padding-top: 2rem;
            padding-bottom: 4rem;
        }

        section[data-testid="stSidebar"] {
            background: var(--ds-inkwell);
            border-right: 0;
            color: var(--ds-white);
            box-shadow: 12px 0 30px rgba(19, 0, 50, 0.12);
            min-width: 17rem;
        }

        section[data-testid="stSidebar"] * {
            color: inherit;
        }

        section[data-testid="stSidebar"] [data-baseweb="select"] *,
        section[data-testid="stSidebar"] input,
        section[data-testid="stSidebar"] textarea {
            color: var(--ds-inkwell) !important;
        }

        section[data-testid="stSidebar"] label,
        section[data-testid="stSidebar"] .stMarkdown p {
            color: rgba(255, 255, 255, 0.82);
        }

        section[data-testid="stSidebar"] hr {
            border-color: rgba(203, 194, 255, 0.24);
        }

        .ds-hero {
            background:
                radial-gradient(circle at 93% 18%, rgba(255, 82, 82, 0.22), transparent 26%),
                linear-gradient(135deg, var(--ds-cobalt) 0%, var(--ds-deep-violet) 74%);
            border-radius: 8px;
            box-shadow: var(--ds-soft-shadow);
            color: var(--ds-white);
            margin-bottom: 1.25rem;
            overflow: hidden;
            padding: 2rem 2.25rem;
            position: relative;
        }

        .ds-hero::after {
            background: linear-gradient(90deg, #4c00ff 0%, #8b19cf 38%, #cf2b8a 68%, #ff5252 100%);
            bottom: 0;
            content: "";
            height: 6px;
            left: 0;
            position: absolute;
            width: 100%;
        }

        .ds-brand-row {
            align-items: center;
            display: flex;
            flex-wrap: wrap;
            gap: 0.75rem;
            margin-bottom: 0.8rem;
        }

        .ds-wordmark {
            color: var(--ds-white);
            font-size: 1.04rem;
            font-weight: 700;
            line-height: 1;
        }

        .ds-pill {
            background: rgba(255, 255, 255, 0.13);
            border: 1px solid rgba(255, 255, 255, 0.26);
            border-radius: 999px;
            color: var(--ds-mist);
            font-size: 0.82rem;
            font-weight: 650;
            line-height: 1.15;
            padding: 0.34rem 0.72rem;
        }

        .ds-hero h1 {
            color: var(--ds-white);
            font-size: 2.15rem;
            font-weight: 760;
            line-height: 1.08;
            margin: 0;
            max-width: 760px;
        }

        .ds-hero p {
            color: var(--ds-ecru);
            font-size: 1.02rem;
            line-height: 1.54;
            margin: 0.7rem 0 0;
            max-width: 760px;
        }

        .ds-section-break {
            background: linear-gradient(90deg, #4c00ff 0%, #8b19cf 38%, #cf2b8a 68%, #ff5252 100%);
            border-radius: 999px;
            box-shadow: 0 10px 26px rgba(76, 0, 255, 0.16);
            height: 6px;
            margin: 1.15rem 0 1.35rem;
            width: 100%;
        }

        .ds-sidebar-brand {
            align-items: center;
            display: flex;
            gap: 0.7rem;
            margin: 0.4rem 0 1.15rem;
        }

        .ds-sidebar-mark {
            align-items: center;
            background: var(--ds-cobalt);
            border: 1px solid rgba(255, 255, 255, 0.24);
            border-radius: 8px;
            color: var(--ds-white);
            display: flex;
            font-weight: 800;
            height: 38px;
            justify-content: center;
            width: 38px;
        }

        .ds-sidebar-title {
            color: var(--ds-white);
            font-weight: 720;
            line-height: 1.1;
        }

        .ds-sidebar-subtitle {
            color: var(--ds-mist);
            font-size: 0.82rem;
            line-height: 1.2;
            margin-top: 0.16rem;
        }

        .ds-empty-history {
            border: 1px solid rgba(203, 194, 255, 0.24);
            border-radius: 8px;
            color: rgba(255, 255, 255, 0.74);
            font-size: 0.9rem;
            line-height: 1.38;
            margin-top: 0.85rem;
            padding: 0.85rem;
        }

        h1, h2, h3, h4 {
            color: var(--ds-inkwell);
            font-weight: 740;
            letter-spacing: 0;
        }

        h2, h3 {
            margin-top: 0.8rem;
        }

        p, li, label, .stMarkdown {
            color: var(--ds-inkwell);
            letter-spacing: 0;
        }

        div[data-testid="stTabs"] button {
            color: var(--ds-muted);
            font-size: 1.12rem;
            font-weight: 820;
            letter-spacing: 0;
            padding-bottom: 0.75rem;
            padding-top: 0.75rem;
        }

        div[data-testid="stTabs"] button p {
            font-size: 1.12rem;
            font-weight: 820;
        }

        div[data-testid="stTabs"] button[aria-selected="true"] {
            color: var(--ds-cobalt);
        }

        div[data-testid="stTabs"] [data-baseweb="tab-highlight"] {
            background-color: var(--ds-cobalt);
        }

        .ds-steps {
            background: rgba(248, 243, 240, 0.72);
            border: 1px solid var(--ds-border);
            border-left: 4px solid var(--ds-cobalt);
            border-radius: 8px;
            display: grid;
            gap: 0.55rem;
            margin: 0.25rem 0 1rem;
            padding: 0.9rem 1rem;
        }

        .ds-steps div {
            color: var(--ds-inkwell);
            font-size: 0.95rem;
            line-height: 1.4;
        }

        .ds-steps strong {
            color: var(--ds-cobalt);
            margin-right: 0.28rem;
        }

        .ds-library-preview {
            background: rgba(248, 243, 240, 0.74);
            border: 1px solid var(--ds-border);
            border-left: 4px solid var(--ds-cobalt);
            border-radius: 8px;
            margin: 0.75rem 0 0.85rem;
            padding: 0.95rem 1rem;
        }

        .ds-library-kicker {
            color: var(--ds-cobalt);
            font-size: 0.78rem;
            font-weight: 780;
            letter-spacing: 0;
            margin-bottom: 0.28rem;
            text-transform: uppercase;
        }

        .ds-library-title {
            color: var(--ds-inkwell);
            font-size: 1.05rem;
            font-weight: 760;
            line-height: 1.25;
            margin-bottom: 0.35rem;
        }

        .ds-library-body {
            color: var(--ds-muted);
            font-size: 0.94rem;
            line-height: 1.42;
        }

        div[data-testid="stExpander"],
        div[data-testid="stDataFrame"],
        div[data-testid="stMetric"] {
            border-color: var(--ds-border) !important;
            border-radius: 8px !important;
        }

        div[data-testid="stExpander"] {
            background: rgba(255, 255, 255, 0.82);
        }

        div[data-testid="stMetric"] {
            background: var(--ds-white);
            box-shadow: 0 10px 30px rgba(19, 0, 50, 0.05);
            padding: 0.75rem 0.9rem;
        }

        div[data-testid="stMetric"] label {
            color: var(--ds-muted);
        }

        div[data-testid="stMetricValue"] {
            color: var(--ds-cobalt);
        }

        input,
        textarea,
        div[data-baseweb="select"] > div {
            border-color: var(--ds-border) !important;
            border-radius: 8px !important;
        }

        input:focus,
        textarea:focus,
        div[data-baseweb="select"] > div:focus-within {
            border-color: var(--ds-cobalt) !important;
            box-shadow: 0 0 0 1px var(--ds-cobalt) !important;
        }

        .stButton button, .stDownloadButton button {
            border: 1px solid var(--ds-cobalt);
            border-radius: 8px;
            color: var(--ds-cobalt);
            font-weight: 700;
            min-height: 2.55rem;
        }

        .stButton button:hover, .stDownloadButton button:hover {
            border-color: var(--ds-deep-violet);
            color: var(--ds-deep-violet);
        }

        .stButton button[kind="primary"] {
            background: var(--ds-cobalt);
            border-color: var(--ds-cobalt);
            color: var(--ds-white);
        }

        .stButton button[kind="primary"] p {
            color: var(--ds-white) !important;
        }

        .stButton button[kind="primary"]:hover {
            background: var(--ds-deep-violet);
            border-color: var(--ds-deep-violet);
            color: var(--ds-white);
        }

        .stButton button[kind="primary"]:hover p {
            color: var(--ds-white) !important;
        }

        div[data-testid="stAlert"] {
            border-color: var(--ds-border);
            border-radius: 8px;
        }

        textarea {
            font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
        }

        @media (max-width: 760px) {
            .main .block-container {
                padding-left: 1rem;
                padding-right: 1rem;
            }

            .ds-hero {
                padding: 1.4rem 1.25rem;
            }

            .ds-hero h1 {
                font-size: 1.6rem;
            }
        }
        </style>
        """,
        unsafe_allow_html=True,
    )


if __name__ == "__main__":
    main()
